using UnityEngine;
public class Tracker : MonoBehaviour
{
    public string paramVelX = "VelX";
    public string paramVelZ = "VelZ";
    public string paramSpeed = "Speed";

    public float animatorDampTime = 0.12f;

    Vector3 lastPosition;
    Animator animator;

    void Awake()
    {
        animator = GetComponent<Animator>();
        lastPosition = transform.position;
    }

    void Update()
    {
        // World velocity
        Vector3 worldVel = (transform.position - lastPosition) / Mathf.Max(Time.deltaTime, 1e-6f);
        lastPosition = transform.position;

        // Convert to local space relative to character orientation
        Vector3 localVel = transform.InverseTransformDirection(worldVel);

        float velX = localVel.x;
        float velZ = localVel.z;
        float speed = worldVel.magnitude;

        // Feed animator with damping: use Animator.SetFloat with dampTime and deltaTime
        animator.SetFloat(paramVelX, velX, animatorDampTime, Time.deltaTime);
        animator.SetFloat(paramVelZ, velZ, animatorDampTime, Time.deltaTime);
        animator.SetFloat(paramSpeed, speed, animatorDampTime, Time.deltaTime);
    }
}