using UnityEngine;

public class Steering : MonoBehaviour
{
    public float maxSpeed = 3f;
    public float maxForce = 10f;

    private Vector3 steeringForce;
    private LocomotionScript locomotion;

    void Awake()
    {
        locomotion = GetComponent<LocomotionScript>();
    }

    void Update()
    {
        // Convert steering force -> desired velocity
        Vector3 desiredVelocity = Vector3.ClampMagnitude(steeringForce, maxForce);

        Vector3 finalVelocity = desiredVelocity.normalized * maxSpeed;

        locomotion.SetVelocity(finalVelocity);   // send to RB mover
        // Reset after applying
        steeringForce = Vector3.zero;
    }

    // Called by other scripts (Seek, Avoid, Cohesion, etc.)
    public void AddForce(Vector3 force)
    {
        steeringForce += force;
    }

    public Vector3 CurrentVelocity
    {
        get { return locomotion.CurrentVelocity; }
    }
}
