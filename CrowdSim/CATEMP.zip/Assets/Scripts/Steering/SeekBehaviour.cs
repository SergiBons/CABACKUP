using UnityEngine;

public class SeekBehaviour : MonoBehaviour
{
    public Transform target;
    public float weight = 1f;

    private Steering agent;

    void Awake()
    {
        agent = GetComponent<Steering>();
    }

    void Update()
    {
        if (target != null)
        {
            Vector3 force = Seek(target.position) * weight;
            agent.AddForce(force);
        }
    }

    Vector3 Seek(Vector3 targetPosition)
    {
        Vector3 desired = (targetPosition - transform.position).normalized * agent.maxSpeed;
        return desired - agent.CurrentVelocity;
    }
}
