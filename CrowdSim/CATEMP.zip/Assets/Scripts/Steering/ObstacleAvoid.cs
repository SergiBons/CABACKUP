using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using UnityEngine;

public class ObstacleAvoid : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    //public List<Collider> ColList;
    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider otherCol)
    {
        
    }

    void OnTriggerExit(Collider otherCol)
    {
        
    }
}
