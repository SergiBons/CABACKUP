using UnityEngine;

public class FleeBehaviour : MonoBehaviour
{
    public Transform target;
    public float weight = 5f;

    private Steering agent;

    void Awake()
    {
        agent = GetComponent<Steering>();
    }

    void Update()
    {
        if (target != null)
        {
            Vector3 force = Flee(target.position) * weight;
            agent.AddForce(force);
        }
    }

    Vector3 Flee(Vector3 targetPosition)
    {
        Vector3 desired = (transform.position - targetPosition).normalized * agent.maxSpeed;
        return desired - agent.CurrentVelocity;
    }
}