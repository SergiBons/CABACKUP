using System.Collections.Generic;
using UnityEngine;

public class CrowdGenerator : MonoBehaviour
{
    public GameObject prefab;
    public int count = 20;
    public Vector2 areaSize = new Vector2(10f, 10f);
    public float minDistance = 1.0f;
    public int maxAttempts = 50;

    private List<Vector3> posVect = new List<Vector3>();

    void Start()
    {
        posVect.Clear();

        if (prefab == null)
        {
            Debug.LogError("No prefab assigned.");
            return;
        }

        float halfX = areaSize.x * 0.5f;
        float halfZ = areaSize.y * 0.5f;
        float minDistSqr = minDistance * minDistance;

        for (int i = 0; i < count; i++)
        {
            Vector3 chosen = Vector3.zero;
            bool found = false;

            for (int attempt = 0; attempt < maxAttempts; attempt++)
            {
                float x = Random.Range(-halfX, halfX);
                float z = Random.Range(-halfZ, halfZ);
                Vector3 rP = transform.position + new Vector3(x, 0f, z);
                rP.y = 0f;

                bool tooClose = false;
                for (int j = 0; j < posVect.Count; j++)
                {
                    float dx = posVect[j].x - rP.x;
                    float dz = posVect[j].z - rP.z;
                    if ((dx * dx + dz * dz) <= minDistSqr)
                    {
                        tooClose = true;
                        break;
                    }
                }

                if (!tooClose)
                {
                    chosen = rP;
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                Debug.LogWarning("Couldn't find free spot for instance " + i + ". Skipping.");
                continue;
            }

            posVect.Add(chosen);

            Quaternion rot = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
            GameObject go = Instantiate(prefab, chosen, rot);

            var rb = go.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.position = chosen;
                rb.rotation = rot;
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(transform.position, new Vector3(areaSize.x, 0.1f, areaSize.y));
    }
}
