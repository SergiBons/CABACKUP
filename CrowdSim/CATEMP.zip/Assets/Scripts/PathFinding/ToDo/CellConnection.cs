using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using PathFinding;

public class CellConnection : Connection<GridCell>
{
	// Class that represent the connection between 2 GridCells
	protected Vector3 location;
	public CellConnection(GridCell from, GridCell to):base(from,to){
		location = from.center - to.center;	
		// setCost ( ?? );
	}

	public CellConnection(GridCell from, GridCell to, Vector3 loc):base(from,to){
		location = loc;	
		// setCost ( ?? );
	}
};
