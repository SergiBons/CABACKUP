using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using PathFinding;

public class GridConnections : NodeConnections<GridCell, CellConnection>
{
	// Class to handle a list of CellConnections
	
	// NOTHING TO DO HERE
};
