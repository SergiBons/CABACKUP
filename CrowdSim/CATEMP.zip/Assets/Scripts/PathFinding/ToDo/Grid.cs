using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using PathFinding;
using System.Data;
using System.Diagnostics;

public class Grid : FiniteGraph<GridCell, CellConnection, GridConnections>
{
	// Class that represent the finite graph corresponding to a grid of cells
	// There is a known set of nodes (GridCells), 
	// and a known set of connections (CellConnections) between those nodes (GridConnections)
	
	// Example Data 
	
	protected float xMin;
	protected float xMax;
	protected float zMin;
	protected float zMax;
	
	protected float gridHeight;
	
	protected float sizeOfCell;
	
	protected int numCells;
	protected int numRows;
	protected int numColumns;
	
	
	// You have basically to fill the base fields "nodes" and "connections", 
	// i.e. create your list of GridCells (with random obstacles) 
	// and then create the corresponding GridConnections for each one of them
	// based on where the obstacles are and the valid movements allowed between GridCells. 
	 public Grid(float minX, float maxX, float minZ, float maxZ, float cellSize, float height = 0):base()
    {
		xMin = minX;
		xMax = maxX;
		zMin = minZ;
		zMax = maxZ;
		sizeOfCell = cellSize;
		numColumns = (int)((maxX - minX) / cellSize);
		numRows    = (int)((maxZ - minZ) / cellSize);
		numCells = numColumns * numRows;
		FillGrid();
	}

	void FillGrid()
    {
		//init nodes
		//UnityEngine.Debug.Log(numCells);
		for(int i = 0;i<numCells; i++ )
        {
            nodes.Add(new GridCell(i,sizeOfCell,numColumns,numRows, 0.3f));
			//UnityEngine.Debug.Log(i);
        }
		//Now for connections,
		//process corners separatedly:
		{
			//bottom left corner:
			int cornerCell = 0;
			if (nodes[cornerCell].occupied == false)
			{
				GridConnections conList = new GridConnections();
				if(nodes[1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[1]));
				if(nodes[numColumns].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[numColumns]));
				if(nodes[numColumns+1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[numColumns+1]));
				connections.Add(conList);
			}
			//bottom right corner:
			cornerCell = numColumns-1;
			if (nodes[cornerCell].occupied == false)
			{
				GridConnections conList = new GridConnections();
				if(nodes[cornerCell-1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-1]));
				if(nodes[2*cornerCell].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[2*cornerCell]));
				if(nodes[2*cornerCell-1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[2*cornerCell-1]));
				connections.Add(conList);
			}
			//top left corner:
			cornerCell = numCells-numColumns;
			if (nodes[cornerCell].occupied == false)
			{
				GridConnections conList = new GridConnections();
				if(nodes[cornerCell+1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell+1]));
				if(nodes[cornerCell-numColumns].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-numColumns]));
				if(nodes[cornerCell-numColumns+1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-numColumns+1]));
				connections.Add(conList);
			}
			//top right corner:
			cornerCell = numCells-1;
			if (nodes[cornerCell].occupied == false)
			{
				GridConnections conList = new GridConnections();
				if(nodes[cornerCell-1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-1]));
				if(nodes[cornerCell].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-numColumns]));
				if(nodes[cornerCell-numColumns-1].occupied == false)
					conList.Add(new CellConnection(nodes[cornerCell],nodes[cornerCell-numColumns-1]));
				connections.Add(conList);
			}
		}
        //process borders, excluding corners:
        {
			//bottom border
            for (int i = 1; i< numColumns-2; i++)
            {
				if (nodes[i].occupied == false)
                {
					GridConnections conList = new GridConnections();
					if (nodes[i-1].occupied == false)
						conList.Add(new CellConnection(nodes[i],nodes[i-1]));
					if (nodes[i+1].occupied == false)
						conList.Add(new CellConnection(nodes[i],nodes[i+1]));
					if (nodes[i-1+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[i],nodes[i-1+numColumns]));
					if (nodes[i+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[i],nodes[i+numColumns]));
					if (nodes[i+1+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[i],nodes[i+1+numColumns]));
					connections.Add(conList);
                }
            }
			//top border
			int referencePoint = numCells-numColumns;
            for (int i = 1; i< numColumns-2; i++)
            {
				if (nodes[referencePoint+i].occupied == false)
                {
					GridConnections conList = new GridConnections();
					if (nodes[referencePoint+i-1].occupied == false)
						conList.Add(new CellConnection(nodes[referencePoint+i],nodes[referencePoint+i-1]));
					if (nodes[referencePoint+i+1].occupied == false)
						conList.Add(new CellConnection(nodes[referencePoint+i],nodes[referencePoint+i+1]));
					if (nodes[referencePoint+i-1-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[referencePoint+i],nodes[referencePoint+i-1-numColumns]));
					if (nodes[referencePoint+i-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[referencePoint+i],nodes[referencePoint+i-numColumns]));
					if (nodes[referencePoint+i+1-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[referencePoint+i],nodes[referencePoint+i+1-numColumns]));
					connections.Add(conList);
                }
            }
			//left border
			for (int j = 1; j< numRows-2; j++)
            {
				int newJ=numColumns*j;
				if (nodes[newJ].occupied == false)
                {
					GridConnections conList = new GridConnections();
					if (nodes[newJ-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-numColumns]));
					if (nodes[newJ-numColumns+1].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-numColumns+1]));
					if (nodes[newJ+1].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ+1]));
					if (nodes[newJ+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ+numColumns]));
					if (nodes[newJ+1+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ+1+numColumns]));
					connections.Add(conList);
				}
            }
			//Right border
			for (int j = 1; j< numRows-2; j++)
            {
				int newJ=numColumns*j+numColumns-1;
				if (nodes[newJ].occupied == false)
                {
					GridConnections conList = new GridConnections();
					if (nodes[newJ-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-numColumns]));
					if (nodes[newJ-numColumns-1].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-numColumns-1]));
					if (nodes[newJ-1].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-1]));
					if (nodes[newJ+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ+numColumns]));
					if (nodes[newJ-1+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[newJ],nodes[newJ-1+numColumns]));
					connections.Add(conList);
                }
                
            }
		}
        //finally the general case, for all the matrix except the borders
		for(int i = 1; i < numColumns-2;i++)
		{
			for(int j = 1; j < numRows-2;j++)
			{
				int selfI = i+j*numColumns;
				if (nodes[selfI].occupied == false)
				{
					GridConnections conList = new GridConnections();
					if (nodes[selfI-numColumns-1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI-numColumns-1]));
					if (nodes[selfI-numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI-numColumns]));			
					if (nodes[selfI-numColumns+1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI-numColumns+1]));		
					if (nodes[selfI-1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI-1]));		
					if (nodes[selfI+1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI+1]));	
					if (nodes[selfI+numColumns-1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI+numColumns-1]));
					if (nodes[selfI+numColumns].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI+numColumns]));			
					if (nodes[selfI+numColumns+1].occupied == false)
						conList.Add(new CellConnection(nodes[selfI],nodes[selfI+numColumns+1]));
					connections.Add(conList);
				}									
			}
		}
    }
};
