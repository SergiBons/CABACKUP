using UnityEngine;
using PathFinding;
public class GridManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public float minX;
    public float maxX;
    public float minZ;
    public float maxZ;
    public float cellSize;

    public GameObject prefab;


    Grid grid; 
    void Start()
    {
        grid = new Grid(minX,maxX,minZ,maxZ,cellSize); 
        foreach (GridCell gc in grid.nodes)
        {
            if (gc.occupied)
                Instantiate(prefab, gc.center, Quaternion.identity);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;

        Vector3 p1 = new Vector3(minX, 0f, minZ);
        Vector3 p2 = new Vector3(maxX, 0f, minZ);
        Vector3 p3 = new Vector3(maxX, 0f, maxZ);
        Vector3 p4 = new Vector3(minX, 0f, maxZ);

        Gizmos.DrawLine(p1, p2);
        Gizmos.DrawLine(p2, p3);
        Gizmos.DrawLine(p3, p4);
        Gizmos.DrawLine(p4, p1);
    }
}
