using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using PathFinding;

public class GridCell : Node 
{
	public GameObject prefab;
	public GridCell(int i):base(i) {
		// TO IMPLEMENT
		//by default set a 15x15 grid.
		float obstacleProb = 0.3f;
		size = 2;
		center = new Vector3( i%15 -7, 0, (int)(i/15)-7);
		xMin = center.x-size/2;
		zMin = center.z-size/2;
		xMax = center.x+size/2;
		zMax = center.z+size/2;
		occupied = Random.Range(0.0f,1.0f) <= obstacleProb;

	}

	public GridCell(int i, float Csize, int numCols, int numRows, float obstacleProb = 0.3f):base(i) {
	//Set a regular grid of gridSize
	size = Csize;

    int col = i % numCols;
    int row = i / numCols;

    float halfWidth  = numCols * Csize * 0.5f;
    float halfHeight = numRows * Csize * 0.5f;

    float x = col * Csize + Csize * 0.5f - halfWidth;
    float z = row * Csize + Csize * 0.5f - halfHeight;

    center = new Vector3(x, 0f, z);

    xMin = center.x - size * 0.5f;
    xMax = center.x + size * 0.5f;
    zMin = center.z - size * 0.5f;
    zMax = center.z + size * 0.5f;

    occupied = Random.Range(0f, 1f) <= obstacleProb;
	}
	public GridCell(GridCell n):base(n) {
		xMin = n.xMin;
		xMax = n.xMax;
		zMin = n.zMin;
		zMax = n.zMax;
		occupied = n.occupied;
		center = n.center;
		size = n.size;
	}

	// Your class that represents a grid cell node derives from Node

	// You add any data needed to represent a grid cell node

	// EXAMPLE DATA
	
	protected float xMin;
	protected float xMax;
	protected float zMin;
	protected float zMax;

	public bool occupied;

	public Vector3 center;
	
	protected float size;

	// You also add any constructors and methods to implement your grid cell node class

	// TO IMPLEMENT
};
