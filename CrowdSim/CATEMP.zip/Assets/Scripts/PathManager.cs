using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathManager : MonoBehaviour
{
    private List<CharacterAgent> agents = new List<CharacterAgent>();

    IEnumerator Start()
    {
        yield return null; // wait one frame to let CrowdGenerator spawn agents

        agents.Clear();
        agents.AddRange(GameObject.FindObjectsByType<CharacterAgent>(FindObjectsSortMode.None));
        Debug.Log($"Found {agents.Count} agents after delay");

        foreach (var agent in agents)
        {
            agent.OnReachedGoalEvent -= OnAgentReachedGoal;
            agent.OnReachedGoalEvent += OnAgentReachedGoal;

            AssignGoalToAgent(agent);
        }
    }

void OnAgentReachedGoal(CharacterAgent agent)
{
    if (agent == null) return;

    if (Simulator.Instance != null)
    {
        AssignGoalToAgent(agent);
    }
}

    private void AssignGoalToAgent(CharacterAgent agent)
    {
        if (Simulator.Instance == null)
        {
            Debug.LogError("PathManager: No Simulator instance found.");
            return;
        }

        Vector3 newGoal = Simulator.Instance.GetUniqueGoal();
        agent.SetGoal(newGoal);
    }
}
