using UnityEngine;

[RequireComponent(typeof(Transform))]
public class OrientationHandler : MonoBehaviour
{
    [Tooltip("Degrees per second the agent can rotate")]
    public float rotationSpeed = 1440f;      // degrees / second

    [Tooltip("Minimum planar speed required to orient")]
    public float minSpeedToOrient = 0.1f;

    Rigidbody rb;
    LocomotionScript locomotion;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        locomotion = GetComponent<LocomotionScript>();

        if (rb == null)
            Debug.LogWarning($"OrientationHandler: No Rigidbody found on {gameObject.name}");

        // locomotion is optional but preferred when using MovePosition (kinematic movement)
        if (locomotion == null)
            Debug.Log($"OrientationHandler: No LocomotionScript found on {gameObject.name}; falling back to Rigidbody.velocity");
    }

    void FixedUpdate()
    {
        // Get the most-relevant velocity: locomotion's internal velocity if available, otherwise Rigidbody.velocity
        Vector3 velocity = Vector3.zero;

        if (locomotion != null)
            velocity = locomotion.CurrentVelocity;
        else if (rb != null)
            velocity = rb.linearVelocity;

        // Project onto horizontal plane so we don't tilt the agent
        Vector3 flatVel = Vector3.ProjectOnPlane(velocity, Vector3.up);

        if (flatVel.sqrMagnitude < minSpeedToOrient * minSpeedToOrient)
            return; // too slow to orient

        Quaternion targetRot = Quaternion.LookRotation(flatVel.normalized, Vector3.up);
        Quaternion currentRot = transform.rotation;

        // Determine max degrees we can rotate this physics step
        float maxDegrees = rotationSpeed * Time.fixedDeltaTime;

        Quaternion newRot = Quaternion.RotateTowards(currentRot, targetRot, maxDegrees);

        // If we have a non-kinematic Rigidbody, use MoveRotation for physics friendliness
        if (rb != null && !rb.isKinematic)
        {
            rb.MoveRotation(newRot);
        }
        else
        {
            // Otherwise directly set transform.rotation (works for kinematic or no-RB setups)
            transform.rotation = newRot;
        }
    }
}
