using UnityEngine;

public class LocomotionScript : MonoBehaviour
{
    public float acceleration = 10f;
    public Vector3 CurrentVelocity => velocity;
    private Rigidbody rb;
    private Vector3 velocity;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.interpolation = RigidbodyInterpolation.Interpolate;
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + velocity * Time.fixedDeltaTime);
    }

    public void SetVelocity(Vector3 newVelocity)
    {
        velocity = Vector3.MoveTowards(
            velocity,
            newVelocity,
            acceleration * Time.deltaTime
        );
    }

}
