using System.Collections.Generic;
using UnityEngine;

public class Simulator : MonoBehaviour
{
    public static Simulator Instance;

    public int goalCount = 30;
    public Vector2 goalAreaSize = new Vector2(20f, 20f);

    private List<Vector3> goals = new List<Vector3>();
    private HashSet<int> assigned = new HashSet<int>();

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        GenerateGoals();
    }

    public void GenerateGoals()
    {
        goals.Clear();
        assigned.Clear();

        float halfX = goalAreaSize.x * 0.5f;
        float halfZ = goalAreaSize.y * 0.5f;

        for (int i = 0; i < goalCount; i++)
        {
            float x = Random.Range(-halfX, halfX);
            float z = Random.Range(-halfZ, halfZ);
            Vector3 pos = transform.position + new Vector3(x, 0f, z);
            pos.y = 0f;
            goals.Add(pos);
        }
    }

    public Vector3 GetUniqueGoal()
    {
        if (goals.Count == 0)
        {
            Debug.LogWarning("Simulator: no goals available");
            return transform.position;
        }

        if (assigned.Count >= goals.Count)
            assigned.Clear();

        List<int> free = new List<int>();
        for (int i = 0; i < goals.Count; i++)
            if (!assigned.Contains(i)) free.Add(i);

        int idx = free[Random.Range(0, free.Count)];
        assigned.Add(idx);
        return goals[idx];
    }

    public void ReleaseGoal(Vector3 goal)
    {
        int idx = goals.IndexOf(goal);
        if (idx >= 0) assigned.Remove(idx);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(transform.position, new Vector3(goalAreaSize.x, 0.1f, goalAreaSize.y));
        if (goals != null)
        {
            Gizmos.color = Color.cyan;
            foreach (var g in goals) Gizmos.DrawSphere(g + Vector3.up * 0.05f, 0.15f);
        }
    }
}
