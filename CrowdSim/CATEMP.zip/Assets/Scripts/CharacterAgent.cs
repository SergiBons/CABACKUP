using System;
using System.Collections;
using UnityEngine;

public class CharacterAgent : MonoBehaviour
{
    public float speed = 3f;
    public float reachThreshold = 0.4f;
    public float goalAssignDelay = 0.25f;

    private Vector3 currentGoal;
    private bool hasGoal = false;
    private bool waiting = false;

    private LocomotionScript locomotion;

    // Add this event
    public event Action<CharacterAgent> OnReachedGoalEvent;

    void Awake()
    {
        locomotion = GetComponent<LocomotionScript>();
        if (locomotion == null)
            Debug.LogError("AgentController requires LocomotionScript component.");
    }

    void Update()
    {
        if (!hasGoal || waiting)
        {
            locomotion.SetVelocity(Vector3.zero);
            return;
        }

        Vector3 toGoal = currentGoal - transform.position;
        toGoal.y = 0f;
        float dist = toGoal.magnitude;

        if (dist <= reachThreshold)
        {
            StartCoroutine(OnReachedGoal());
            locomotion.SetVelocity(Vector3.zero);
            return;
        }

        Vector3 desiredVel = toGoal.normalized * speed;
        locomotion.SetVelocity(desiredVel);
    }

    IEnumerator OnReachedGoal()
    {
        if (waiting) yield break;
        waiting = true;

        // Fire the event to notify listeners
        OnReachedGoalEvent?.Invoke(this);

        if (Simulator.Instance != null && hasGoal)
            Simulator.Instance.ReleaseGoal(currentGoal);

        hasGoal = false;

        yield return new WaitForSeconds(goalAssignDelay);

        AssignNewGoal();

        waiting = false;
    }

    public void AssignNewGoal()
    {
        if (Simulator.Instance == null)
        {
            Debug.LogError("No Simulator instance found!");
            return;
        }

        currentGoal = Simulator.Instance.GetUniqueGoal();
        hasGoal = true;
    }
    public void SetGoal(Vector3 goal)
    {
        currentGoal = goal;
        hasGoal = true;
        waiting = false; // reset waiting if needed
    }

}
